from datetime import datetime, timedelta
from kafka import KafkaProducer
import json
import requests
import logging
import time  # Import the time module

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def get_data():
    res = requests.get("https://randomuser.me/api/")
    res = res.json()
    res = res['results'][0]
    return res

def format_data(res):
    data = {}
    location = res['location']

    data['first_name'] = res['name']['first']
    data['last_name'] = res['name']['last']
    data['gender'] = res['gender']
    data['address'] = f"{str(location['street']['number'])} {location['street']['name']}, {location['city']}, {location['state']}, {location['country']}"
    data['postcode'] = location['postcode']
    data['email'] = res['email']
    data['username'] = res['login']['username']
    data['dob'] = res['dob']['date']
    data['registered_date'] = res['registered']['date']
    data['phone'] = res.get('phone', None)
    data['picture'] = res['picture']['medium'] if 'picture' in res else None

    return data

def stream_data():
    try:
        while True:  # Infinite loop for continuous streaming
            logger.debug("Fetching data from API...")
            res = get_data()
            logger.debug(f"Raw data: {res}")

            formatted_data = format_data(res)

            logger.debug(f"Formatted data: {formatted_data}")

            # Initialize Kafka producer
            logger.debug("Initializing Kafka producer...")
            producer = KafkaProducer(bootstrap_servers=['localhost:9092'], max_block_ms=5000)

            # Send data to Kafka topic 'users_created'
            logger.debug(f"Sending data to Kafka topic 'users_created': {formatted_data}")
            producer.send('users_created', json.dumps(formatted_data).encode('utf-8'))

            logger.debug("Closing Kafka producer...")
            producer.close()

            print(json.dumps(formatted_data))
            time.sleep(1)  # Introduce a one-second delay before fetching data again

    except Exception as e:
        logger.error(f'An error occurred: {e}')

if __name__ == "__main__":
    stream_data()
