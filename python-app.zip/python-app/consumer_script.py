from kafka import KafkaConsumer
import json
import logging
import time
import pandas as pd
from sqlalchemy import create_engine
import psycopg2

# Initialize Kafka consumer
consumer = KafkaConsumer('users_created', bootstrap_servers=['localhost:9092'], group_id='my-group')


data_list = []


try:
    for message in consumer:
        print(f"Received raw message: {message}")
        data = json.loads(message.value.decode('utf-8'))
        print("Received Data:", data)
        data_list.append(data)
        df = pd.DataFrame(data_list)
        print(df.head())
        #df.to_sql('user_data', engine, if_exists='append', index=False)

    # Close the Kafka consumer outside the loop
    consumer.close()

    # df = pd.DataFrame(data_list)
    # print(df.head())

    # Store the DataFrame in PostgreSQL using the SQLAlchemy engine
    # df.to_sql('user_data', engine, if_exists='append', index=False)

except Exception as e:
    print(f'An error occurred: {e}')
